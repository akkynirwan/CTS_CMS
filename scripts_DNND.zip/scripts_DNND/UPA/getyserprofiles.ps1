add-pssnapin "Microsoft.Sharepoint.Powershell";
$siteList = Get-SPSite -Identity "http://na01.novartis.net";
$serviceContext = Get-SPServiceContext($siteList);
$profileManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($serviceContext);
foreach($userProfile in $profileManager.GetEnumerator()) {
Write-Host "$userProfile.AccountName"
$value=$userProfile.AccountName;
$value | Out-file "accounts.csv" -append
}