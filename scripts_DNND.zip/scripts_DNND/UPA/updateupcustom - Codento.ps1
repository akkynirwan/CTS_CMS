#First load the SharePoint commands 
add-PSSnapIn Microsoft.SharePoint.PowerShell 

#Set up the job variables 
$csvfile="update swis code nto.csv" 
$mySiteUrl = "http://na01.novartis.net"
$upAttributes = "OperationalLevel1Code", "OperationalLevel2Code", "OperationalLevel3Code"
$gc = Start-SPAssignment
#Connect to User Profile Manager service 
$site = ($gc | Get-SPSite $mySiteUrl) 
$context = ($gc | Get-SPServiceContext -Site $site)
$profileManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileManager($context) 

#Create Lists from each item in CSV file 
Import-Csv $csvfile | ForEach-Object{

    #Check to see if user profile exists 
    if ($profileManager.UserExists($_.FedId)) 
        { 
            #Get user profile and change the value 
            $up = $profileManager.GetUserProfile($_.FedId)
foreach($upattribute in $upattributes)
{
            $up[$upAttribute].Value = $_.($upAttribute) 
}
            $up.Commit() 
            write-host "Profile $_.FedId updated"
        } 
    else 
    { 
        write-host "Profile for user"$_.FedId "cannot be found" 
    } 
} 

#Dispose of site object 
Stop-SPAssignment $gc