function Remove-SPUserProfile([Microsoft.Office.Server.UserProfiles.UserProfileManager]$upm, [string]$accountName)
{
    if($upm.UserExists($accountName))
    {
        $userProfile = $upm.GetUserProfile($accountName)
        $id = $userProfile.ID
        $upm.RemoveUserProfile($id)
    }
    else
    {
        Write-Host $accountName " does not exist"
    }
    
}

function Process-DeletedUserProfiles([string]$siteUrl, [string[]]$user)
{
    $gc = Start-SPAssignment
    $site = ($gc | Get-SPSite $siteUrl)
    $context = ($gc | Get-SPServiceContext -Site $site)
    $upm = new-object Microsoft.Office.Server.userProfiles.UserProfileManager($context)
   
        Remove-SPUserProfile $upm $user

    Stop-SPAssignment $gc
}
$csvfile = "deleteup.csv"
Import-Csv $csvfile | ForEach-Object{
        Write-Host "Deleting User" $_.UserId
 Process-DeletedUserProfiles http://gpchbs-sp326402:2000 $_.UserId}