﻿############################################################################
#WarmUp.ps1 - Enumerates all web sites in web applications in a 2013
# SharePoint farm and opens each in a browser.
#Notes:
#- for "get-webpage" function refer to:
# http://kirkhofer.wordpress.com/2008/10/18/sharepoint-warm-up-script/
#Scrip should be Running on machine with WSS/SP 2013 installed
############################################################################
 
Add-PsSnapin Microsoft.SharePoint.PowerShell
$extrasitelistfile = 'D:\Warmup\warmupsites.txt'
 
function get-webpage([string]$url,[System.Net.NetworkCredential]$cred=$null)
{
Try{
  $wc = new-object net.webclient
  if($cred -eq $null)
  {
    $cred = [System.Net.CredentialCache]::DefaultCredentials;
  }
  $wc.credentials = $cred;
  return $wc.DownloadString($url);
  }
  catch
{
$ErrorMessage = $_.Exception.Message

Add-Content "D:\logWarmup.txt" -Value $ErrorMessage
}
}
 
#This passes in the default credentials needed. If you need specific
#stuff you can use something else to elevate basically the permissions.
#Or run this task as a user that has a Policy above all the Web
#Applications with the correct permissions
 
$cred = [System.Net.CredentialCache]::DefaultCredentials;
#$cred = new-object System.Net.NetworkCredential("username","password","machinename")
 
$apps = get-spwebapplication -includecentraladministration
foreach ($app in $apps) {
Try{
 $sites = get-spsite -webapplication $app.url
  foreach ($site in $sites) {
    write-host $site.Url;
    $html=get-webpage -url $site.Url -cred $cred;
  }
 }
 catch
{
$ErrorMessage = $_.Exception.Message

Add-Content "D:\logWarmup.txt" -Value $ErrorMessage
}
}

# Warm up other sites specified in warmup-extrasites.txt file (such as SSRS)
 
if (test-path $extrasitelistfile) {
  $extrasites = get-content $extrasitelistfile
  foreach ($site in $extrasites) {
  Try{
    write-host $site;
    $html=get-webpage -url $site -cred $cred;
  }
  catch
{
$ErrorMessage = $_.Exception.Message

Add-Content "D:\logWarmup.txt" -Value $ErrorMessage
}
  }
}