#Site URL
$web = Get-SPWeb "http://commssource.novartis.net"
#$web.AllowUnsafeUpdates = $true;    

#List Name
$list = $web.Lists["Topics"]

# Iterate through all Items in List and all Workflows on Items.         
foreach ($item in $list.Items) {
foreach ($wf in $item.Workflows) {
if($wf.StatusText -match 'Error Occurred')
{
#Cancel Workflows        
#[Microsoft.SharePoint.Workflow.SPWorkflowManager]::CancelWorkflow($wf);
write-host $wf $item.ID
}
}
}
$web.Dispose();