$webapplist = get-spwebapplication
foreach($webapp in $webapplist){
$sites = get-spsite -webapplication $webapp -limit all
write-host $webapp.name $sites.count -foregroundcolor yellow
$lockcount = 0
foreach($site in $sites){
if ($site.ReadOnly -eq $null -and $site.ReadLocked -eq $null -and $site.WriteLocked -eq $null){$lockcount= $lockcount + 1}
}
write-host Lock Count: $lockcount -foregroundcolor red
}