
#param($WebAppURL)
#Add SharePoint PowerShell SnapIn if not already added

$file = "Vat_Con_UAR.csv"

function add_sharepoint_snapin
{
    if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) 
    {
        Add-PSSnapin "Microsoft.SharePoint.PowerShell"
    } 
}

Function GetUserAccessReport($Web) 
{ 
       
  
          #Get all the users granted permissions to the list 
             foreach($WebRoleAssignment in $Web.RoleAssignments )  
                 {  
                   #Is it a User Account? 
                     if($WebRoleAssignment.Member.userlogin)     
                      { 
                        #Write-Host  $SearchUser has direct permissions to site $Web.Url 
                        #Get the Permissions assigned to user 
                        $WebUserPermissions=@() 
                        foreach ($RoleDefinition  in $WebRoleAssignment.RoleDefinitionBindings) 
                            { 
                                 $WebUserPermissions += $RoleDefinition.Name +";"
                            } 
                         #write-host "with these permissions: " $WebUserPermissions 
                         #Send the Data to Log file 
                        "$($Web.Url) `t Site `t $($Web.Title) `t $($WebRoleAssignment.Member.userlogin) `t $($user.Email) `t $($WebRoleAssignment.Member.DisplayName) `t Direct Permission `t $($WebUserPermissions)" | Out-File $file  -Append
                      } 
                   #Its a SharePoint Group, So search inside the group and check if the user is member of that group 
                    else   
                        { 
                         foreach($user in $WebRoleAssignment.member.users) 
                            { 
                               #Write-Host  "$SearchUser is Member of " $WebRoleAssignment.Member.Name "Group" 
                               #Get the Group's Permissions on site 
                               $WebGroupPermissions=@() 
                               foreach ($RoleDefinition  in $WebRoleAssignment.RoleDefinitionBindings) 
                               { 
                                    $WebGroupPermissions += $RoleDefinition.Name +";"
                               } 
                                 #write-host "Group has these permissions: " $WebGroupPermissions 
           
                                #Send the Data to Log file 
         "$($Web.Url) `t Site `t $($Web.Title) `t $($user) `t $($user.Email) `t $($user.DisplayName) `t  Member of $($WebRoleAssignment.Member.Name) Group `t $($WebGroupPermissions)" | Out-File $file -Append
        } 
       } 
      } 
                  
} 
   
#Write CSV- TAB Separated File) Header
"URL `t Site/List `t Title  `t UserID `t Email `t Username `t PermissionType `t Permissions" | out-file $file
add_sharepoint_snapin
#$WebAppURL="http://corporatevolunteering.novartis.net"
$SiteCollections = Get-SPSite https://spapps.novartis.net/sites/eea  -Limit All
  foreach($Site in $SiteCollections)  
  {
	#$Site.url
	#if($Site.url -Contains "https://vat-con.novartis.net/")
         #{
	$Site.url
    foreach($Web in $Site.AllWebs)  
       {  
          
           
            $user1.DisplayName
            GetUserAccessReport -Web $Web
            
         }
     #}
}
  
  