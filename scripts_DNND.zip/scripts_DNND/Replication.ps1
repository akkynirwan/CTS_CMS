Add-PSSnapin Microsoft.Office.Server.AdministrationToolkit.ReplicationEngine
 
Start-SPProfileServiceFullReplication -Destination http://na01.novartis.net/ -Source https://my.novartis.net -MaxNumberOfThreads 40 -Properties "DivisionCode,SiteCode"
#Start-SPProfileServiceRecoveryReplication  -Destination http://na01.novartis.net/ -FileName "d:\accounts.txt"  -Source https://my.novartis.net
