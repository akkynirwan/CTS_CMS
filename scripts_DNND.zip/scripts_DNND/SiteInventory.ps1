#Inventory script:


###############################################################
#
#        Inventory by Web Application
#
###############################################################

# Set Farm Variables
$currentPhysicalPath=Split-Path -Parent $PSCommandPath
$Environment = "NISP2013ProdPlatform"
#$outfilepath = "d:\scripts"

###############################################################

#No modifications needed below this line

Add-PSSnapin "Microsoft.SharePoint.PowerShell"

$Webapplist = get-spwebapplication
Foreach($webapp in $Webapplist)
{
$web = get-spwebapplication $webapp

    $webdisplayname = $web.displayname
    $outfile = $currentPhysicalPath + "\Inventory\" + $Environment + "_Inventory_" + $webdisplayname + ".csv"
    $string = "Environment| URL| Title| Last Content Modified Date| Usage (MB)| Owner| Secondary Owner| NoAccess| ReadOnly| Content Database"
    $string | out-file $outfile
foreach($site in $web.Sites)
{
Write-host "Getting Data For: "  $site.URL -ForegroundColor Yellow 
            $web1 = get-spweb $site.url
$date = $site.LastContentModifiedDate.ToShortDateString()
$size = $site.usage.storage/1MB
#$owner = $site.Owner
$string = $Environment, $site.Url, $web1.title, $date, $size, $site.Owner, $site.SecondaryContact, $site.IsReadLocked, $site.WriteLocked, $site.contentdatabase -join "`t"
$string = $string + $user -replace "@{UserLogin=","" -replace"}","" -replace "SPContentDatabase Name=",""
$string | out-file $outfile -append
}
}



