﻿Start-SPAssignment -Global
$webapps = Get-SPWebApplication

Add-Content "D:\temp\Applications.csv" "Name,URL"  

Foreach($webapp in $webapps)
{
 $sites = Get-SPSite -WebApplication $webapp -Limit ALL
 Foreach($site in $sites)
 {
    $Name = $site.RootWeb.Title;
    $url = $site.Url;
   Add-Content "D:\temp\Applications.csv" "$Name,$url" 
 }
 }

 Stop-SPAssignment -Global