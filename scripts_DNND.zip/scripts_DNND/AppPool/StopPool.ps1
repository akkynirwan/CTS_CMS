Import-Module WebAdministration
$applicationPools = Get-ChildItem IIS:\AppPools | ? {$_.state -ne "Stopped"}
foreach($applicationPool in $applicationPools){
Write-host "Stopping application pool ""($($applicationPool.name)"""
$applicationPool.Stop() }