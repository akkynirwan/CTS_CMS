﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
$WebAppURL =Read-host "enter the web app url"
#$WebAppURL ="http://commsblog.novartis.net/"


$SiteCollections = Get-SPSite -WebApplication $WebAppURL -Limit All
$currentPhysicalPath=Split-Path -Parent $PSCommandPath
$ErrorLogFilePath=$currentPhysicalPath+"\Logs\SP_Log_Removal"+$Full_Date +".csv"
$ExclusionDivestmentSitesPath=$currentPhysicalPath+"\ExclusionList.csv"
$UniqueUserassocoatedSitesPath=$currentPhysicalPath+"\Users.csv"

$Users= Import-csv -Path $UniqueUserassocoatedSitesPath
$ExclusionSites= Import-csv -Path $ExclusionDivestmentSitesPath


foreach($Site in $SiteCollections)
{

$Errors=@()
$SiteUrl = $Site.Url
$IsExists=$false

foreach($ExclusionSite in $ExclusionSites)
{
    if($ExclusionSite.SiteUrl.ToLower().Trim() -eq $SiteUrl.ToLower().Trim())
    {
        $IsExists=$true
        break;
    }
}

if(-NOT $IsExists)
{
 $web = Get-SPWeb -identity $SiteUrl
 
 foreach($User in $Users)
    {
        try 
        {    
            $AccountName=$User.AccountName.ToLower().Trim() 

            #$mySiteUrl = "https://appl.eu.novartis.net/"
                
            $user= $web.EnsureUser($AccountName)	
        
            Remove-SPUser -identity $user.LoginName -Web $SiteUrl -confirm:$false
            $web.EnsureUser($user.LoginName)	
        }
        catch{[Exception]   	        if ($_.Exception.InnerException) { $msg = $_.Exception.InnerException.Message } else { $msg = $_.Exception.Message }             $hash = @{"AccountName"=$AccountName;"SiteUrl"=$SiteUrl;"msg"=$msg}
             $Errors += New-Object PSObject -Property $hash
             if($msg -like '*could not be found*')
             {
                 $AccountName="NANET\"+$AccountName

                 try
                 {
                 Remove-SPUser -identity $user.LoginName -Web $SiteUrl -confirm:$false
                 }
                 catch{}	    
             }
        }
    }
}
    $Errors  | Export-Csv $ErrorLogFilePath -notype -Append
}


 