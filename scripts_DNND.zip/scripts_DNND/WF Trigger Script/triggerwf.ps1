﻿$csv=Import-Csv "D:\Temp\hendrre2\items.csv"
$web = Get-SPWeb "http://commssource.novartis.net";    
$manager = $web.Site.WorkFlowManager;    
$list = $web.Lists["Topics"];

$assoc = $list.WorkflowAssociations.GetAssociationByName("Permission Manager - Prod","en-US")

#$view = $list.Views["All Items"]; #All Items

#$items = $list.GetItems($view);    
$data = $assoc.AssociationData;
$items=$list.Items
foreach($c in $csv)
{
$id=$c.ItemID
$item=$items.GetItemById($id)
#$item=$list.GetItemById(655)
$wf = $manager.StartWorkFlow($item,$assoc,$data,$true);
}