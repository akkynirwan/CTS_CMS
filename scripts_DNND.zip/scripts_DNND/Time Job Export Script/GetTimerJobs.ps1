﻿Start-SPAssignment -Global

$webapps = Get-SPWebApplication | Select DisplayName, Url

Add-Content "D:\temp\TimerList.csv" "URL,Name,TimerJob,Type"  

Foreach($webapp in $webapps)
{

$jobs = Get-SPTimerJob -WebApplication $webapp.Url | where{$_.TypeName -notcontains "Microsoft"} | select Name, DisplayName, Status, TypeName 
foreach($job in $jobs)
{

$url = $webapp.Url;
$Name = $job.Name;
$display = $job.DisplayName;
$jobType = $job.TypeName;
Add-Content "D:\temp\TimerList.csv" "$url,$Name,$display,$jobType" 

} 
}

Stop-SPAssignment -Global