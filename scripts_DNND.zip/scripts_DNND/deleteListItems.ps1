Add-PSSnapin microsoft.sharepoint.powershell -ErrorAction SilentlyContinue
$list = (get-spweb "http://groupdirectory.novartis.net").lists["Directory"]
$items = $list.items | % { $_.id}
$items | % {$list.items.DeleteItemById($_)}