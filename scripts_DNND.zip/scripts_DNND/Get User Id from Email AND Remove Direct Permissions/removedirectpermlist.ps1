#Add-PSSnapin "Microsoft.Sharepoint.Powershell"
$gc = Start-SPAssignment
$csvFilePath="D:\Perm Management\Appletree\Directpermsite_list.csv"
Import-Csv $csvFilePath -ErrorAction SilentlyContinue -ErrorVariable  csvErr | ForEach{
$user=$_.UserID
$list=$_.List
$url=$_.Url
$web= Get-SPWeb -Identity "$url"
$spuser = Get-SPUser -Web $web -Identity $user
$splist = $web.Lists["$list"]
 if ($splist.HasUniqueRoleAssignments -eq $true){

                #Remove any explicit role assignments
                $splist.RoleAssignments.Remove($spuser);
Write-Host "removing $spuser from $web $splist"
            }
}
Stop-SPAssignment $gc