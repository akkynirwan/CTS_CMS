#Add-PSSnapin "Microsoft.Sharepoint.Powershell"
$gc = Start-SPAssignment
$csvFilePath="D:\Perm Management\Abhinav\RemoveGroup.csv"
Import-Csv $csvFilePath -ErrorAction SilentlyContinue -ErrorVariable  csvErr | ForEach{
$url=$_.Url
$user=$_.UserID
$group=$_.Group
$web= Get-SPWeb -Identity "$url"
$spuser = Get-SPUser -Web $web -Identity $user
$spgroup = $web.Groups["$group"]
$spgroup.RemoveUser($spuser);
Write-Host "removing $spuser from $web $url $spgroup"
$web.Dispose()
}
Stop-SPAssignment $gc