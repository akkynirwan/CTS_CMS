#Add-PSSnapin "Microsoft.Sharepoint.Powershell"
$gc = Start-SPAssignment
$csvFilePath="D:\Perm Management\Abhinav\Directpermsite.csv"
Import-Csv $csvFilePath -ErrorAction SilentlyContinue -ErrorVariable  csvErr | ForEach{
$user=$_.UserID
$url=$_.Url
$web= Get-SPWeb -Identity "$url"
$spuser = Get-SPUser -Web $web -Identity $user
 if ($web.HasUniqueRoleAssignments -eq $true){

                #Remove any explicit role assignments
                $web.RoleAssignments.Remove($spuser);
Write-Host "removing $spuser from $web"
            }
}
Stop-SPAssignment $gc