﻿$site = Get-SPSite http://commssource.novartis.net 
$groups = $site.RootWeb.sitegroups
foreach ($grp in $groups) {"Group: " + $grp.name; foreach ($user in $grp.users) {"  User: " + $user.UserLogin} }
$site.Dispose()