﻿Function Run-PSConfig
 
{
 
Set-Alias PSCONFIG "${env:commonprogramfiles}\Microsoft Shared\Web Server Extensions\15\BIN\PSCONFIG.EXE"
 
   Start-Process -FilePath PSCONFIG -ArgumentList "-cmd upgrade -inplace b2b -force -cmd installcheck -noinstallcheck" -Wait
 
}
Add-PSSnapin "Microsoft.Sharepoint.Powershell"
$PSConfig = "$env:CommonProgramFiles\Microsoft Shared\Web Server Extensions\$env:spVer\BIN\psconfig.exe"
$starttime = Get-Date
 
Write-Host "Running PSConfig.exe"
 
Run-PSConfig
 
Write-Host 

Write-Host 

$finishtime = Get-Date
 
Write-Host "PSConfig Duration" -ForegroundColor Yellow 

Write-Host "Started: " $starttime -ForegroundColor Yellow 

Write-Host "Finished: " $finishtime -ForegroundColor Yellow 