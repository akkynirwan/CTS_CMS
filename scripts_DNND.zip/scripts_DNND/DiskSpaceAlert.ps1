#Set the timestamp
$date = Get-Date

#Set the server names
$servers = @("GPCHBS-SP326400","GPCHBS-SP326401","GPCHBS-SP326402","GPCHBS-SP326403","GPCHBS-SP321016")

#Set the threshold
$threshold=20

#Set the formatting for the email report
$a = "<style>"
$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
$a = $a + "TH{border-width: 1px;padding: 10px;border-style: solid;border-color: black;background-color:thistle}"
$a = $a + "TD{border-width: 1px;padding: 10px;border-style: solid;border-color: black;background-color:PaleGoldenrod}"
$a = $a + "</style>"

#Send Email Report

$table2 = @()

foreach ($server in $servers)
{

$table1 = get-wmiobject Win32_volume -computername $server |select Name, @{Name="Capacity(GB)";Expression={$_.Capacity/1GB}}, @{Name="FreeSpace(GB)";Expression={$_.FreeSpace/1GB}}, @{Name="FreeSpacePCT";Expression={$_.FreeSpace/$_.Capacity*100}} | Where-Object {([decimal]$_.FreeSpacePCT -lt [decimal]$threshold) -and ($_.Name -ne "Z:\") -and ($_.Name -ne "P:\")} | sort-object -property "FreeSpacePCT"

	if($table1 -ne $null)
	  {
	   $table1 | Add-Member -MemberType NoteProperty "ServerName" -Value $server -force
	   for ($i=0; $i -le $table1.Length-1; $i++) {$table1[$i].Servername = $server}
 	   $table2 += $table1
	   $table1 = $null;
	  }
}
$table3=$table2.GetEnumerator() | sort -Property FreeSpacePCT | Where-Object { $_."Capacity(GB)" -ne '0' }
if($table3 -ne $null) 
{ 
$subject = "Disk Space Alert !!"
$smtpServer = "mail.novartis.com"
$smtpFrom = "ni.collaboration@novartis.com"
$smtpTo = "ni.collaboration@novartis.com"
$messageSubject = $subject
$message = New-Object System.Net.Mail.MailMessage $smtpfrom, $smtpto
$message.Subject = $messageSubject
$message.IsBodyHTML = $true
$message.Body= "Disk with freespace below $threshold % are listed below. Report generated on $date"
$message.Body += $table3 | ConvertTo-HTML  -head $a
$smtp = New-Object Net.Mail.SmtpClient($smtpServer)
$smtp.Send($message)
}