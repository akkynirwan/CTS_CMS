$assignment = Start-SPAssignment
$web = Get-SPWeb -Identity "http://perspectives.novartis.net" -AssignmentCollection $assignment
$rootFolder = $web.RootFolder
$rootFolder.WelcomePage = "Pages/Home.aspx"
#$rootFolder.WelcomePage= "$rootFolder.ServerRelativeUrl _layouts/15/ECN/Pages/Home.aspx"
$rootFolder.Update()
$web.Dispose()
Write-Host �Welcome Page Set Successfully��
Stop-SPAssignment $assignment