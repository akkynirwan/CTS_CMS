Import-Csv D:\OpenShare\shareinfo.csv |`
    ForEach-Object {
        $sharepath = $_.Path
        Write-Host $sharepath
        $acl=get-acl $sharepath
 $accessrule = New-Object system.security.AccessControl.FileSystemAccessRule("Everyone","Read",,,"Allow")
 $acl.RemoveAccessRuleAll($accessrule)
 Set-Acl -Path $sharepath -AclObject $acl
   }

Get-WmiObject -Class Win32_LogicalShareSecuritySetting | foreach {
 $newDescriptor = $_.GetSecurityDescriptor().descriptor
 $newDescriptor.dacl = $_.GetSecurityDescriptor().Descriptor.Dacl | Where {$_.trustee.name -ne 'Everyone'}
 $_.SetSecurityDescriptor($newDescriptor)
}