<#=============================================================================================================
Copyright (c) Cognizant, shared intellectual property with Novartis. All rights reserved.
===============================================================================================================
* Version           :   1.0.0.0
* Created by        :   Cognizant
* Created On        :   29-May-2017
* Script Desription  :  This script will deactivate the master page and look and feel features from the sites.
* =============================================================================================================
* Revision/Change History
* -------------------------------------------------------------------------------------------------------------
* Change ID        | Description     | Last Modified By           | Last Modified On
* -------------------------------------------------------------------------------------------------------------
* #0001            |
* =============================================================================================================#>

try{
	Add-PSSnapin microsoft.sharepoint.powershell
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
	$LogFile = ".\DisableFeatures.csv"

		$websiteCollection=@("http://onc_devblog.novartis.net/","http://onc-developmentblog.novartis.net/","http://onc-presidentblog.novartis.net/","http://globaldevelopment.novartis.net/")
		$featureguidcontentTypes="122cee05-e2fe-431f-a3df-c410b41fadcc"
		$featureguidlist="cd1c7e70-09ea-4d72-aaab-94251840ef55"
		
		

		foreach ($website in $websiteCollection) {					#Execute the script and deactivates the feature $featureguidLookandFeel on all sites
			try {															
				Write-Host "Disabling Features for " $website
				Disable-SPFeature -Identity $featureguidcontentTypes -Url $website -Confirm:$false
				Disable-SPFeature -Identity $featureguidlist -Url $website -Confirm:$false
				
				
				$web = Get-SPWeb $website
				$featurecontentTypes = $web.Features[$featureguidcontentTypes]
				$featureList = $web.Features[$featureguidlist]
				
				
				if ($featurecontentTypes -eq $null)		#check for master page feature
				{
					Write-Host "Master Page Feature is successfully disabled for " $website
					Write-Output " $website, Feature is successfully disabled" | Out-File -FilePath $LogFile -Append
				}
				else 
				{	
					Write-Host "Master Page Feature is still active for " $website 
					Write-Output " $website, Feature is still active" | Out-File -FilePath $LogFile -Append
				}
				if ($featureList -eq $null) 		#check for look and feel feature
				{ 
					Write-Host "Look and feel Feature is successfully disabled for " $website
					Write-Output " $website, Feature is successfully disabled" | Out-File -FilePath $LogFile -Append
				} 
				else 
				{ 
					Write-Host "Look and feel Feature is still active for " $website 
					Write-Output " $website, Feature is still active" | Out-File -FilePath $LogFile -Append
				}
				
				

			}
			catch [System.Exception]{                        
                    Write-Host ([String]::Format("Error in iteration: {0} ",$_)) -ForegroundColor Red -BackgroundColor White; 
                    Write-Output " $website, Error occured in iteration" | Out-File -FilePath $LogFile -Append
            }
			finally {
				$web.Dispose()		#disposing off the web object so that memory leaks can be avoided
			}
		}
	}
	catch [System.Exception]{                        
            Write-Host ([String]::Format("Error occurred: {0}",$_)) -ForegroundColor Red -BackgroundColor White; 
                    
    }

	 