<#=============================================================================================================
Copyright (c) Cognizant, shared intellectual property with Novartis. All rights reserved.
===============================================================================================================
* Version           :   1.0.0.0
* Created by        :   Cognizant
* Created On        :   29-May-2017
* Script Desription  :  This script will activate the look and feel feature from the sites.
* =============================================================================================================
* Revision/Change History
* -------------------------------------------------------------------------------------------------------------
* Change ID        | Description     | Last Modified By           | Last Modified On
* -------------------------------------------------------------------------------------------------------------
* #0001            |
* =============================================================================================================#>

try{
	Add-PSSnapin microsoft.sharepoint.powershell
	[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
	$LogFile = ".\EnableFeatures.csv"

		$websiteCollection=@("http://onc_devblog.novartis.net/","http://onc-developmentblog.novartis.net/","http://onc-presidentblog.novartis.net/","http://globaldevelopment.novartis.net/")
		$featureguidcontentTypes="122cee05-e2fe-431f-a3df-c410b41fadcc"
		$featureguidlist="cd1c7e70-09ea-4d72-aaab-94251840ef55"
		
		foreach ($website in $websiteCollection) {			#Execute the script and Activates the feature on all sites
				Write-Host "Enabling Feature for" $website
			try{
				Enable-SPFeature -Identity $featureguidcontentTypes -Url $website -Force
				Enable-SPFeature -Identity $featureguidlist -Url $website -Force			
				
				$web = Get-SPWeb $website
				$featurecontentTypes = $web.Features[$featureguidcontentTypes]
				$featureList = $web.Features[$featureguidlist]
				
				
				if ($featurecontentTypes -eq $null)		#check for master page feature
				{
					Write-Host "Master Page Feature is successfully enabled for " $website
					Write-Output " $website, Feature is successfully enabled" | Out-File -FilePath $LogFile -Append
				}
				else 
				{	
					Write-Host "Master Page Feature is disabled for " $website 
					Write-Output " $website, Feature is disabled "| Out-File -FilePath $LogFile -Append
				}

				if ($featureList -eq $null) 		#checking for feature $featureList
				{ 
					Write-Host "Look and feel Feature is  disabled for " $website
					Write-Output "$website, Feature is disabled" | Out-File -FilePath $LogFile -Append
				} 
				else 
				{ 
					Write-Host "Look and feel Feature is enabled for " $website 
					Write-Output " $website, Feature is enabled" | Out-File -FilePath $LogFile -Append
				}
			}
			catch [System.Exception]{                        
                    Write-Host ([String]::Format("Error in iteration: {0} ",$_)) -ForegroundColor Red -BackgroundColor White; 
                    Write-Output " $web, Error occured in iteration" | Out-File -FilePath $LogFile -Append
            }
			finally {
				$web.Dispose()		#disposing off the web object so that memory leaks can be avoided
			}
		}
	}
	catch [System.Exception]{                        
            Write-Host ([String]::Format("Error occurred: {0}",$_)) -ForegroundColor Red -BackgroundColor White; 
                    
    }
	

	 