﻿Param([String]$DepType,[String]$logName)
Write-Host $DepType , $logName

Import-Module -Name ".\Common.ps1"

#Add the Sharepoint powershell Snap In
AddPowerShellSnapIn
#Start Dispose Thread#
Start-SPAssignment -Global 
Set-ExecutionPolicy RemoteSigned -ErrorAction SilentlyContinue -ErrorVariable excPolicyErr 
$ExecutionPolicy = Get-ExecutionPolicy
if($excPolicyErr)
{
Write-Host "$excPolicyErr"
}
#Initialize Current Directoy
[string]$currentDir=[String]$(gl)
# Creating timestamp
$dateSuffix = [System.DateTime]::Today.ToString("MM-dd-yy")  
$timeSuffix = [System.DateTime]::Now.ToString("hhmmss") 
#Path For Package
$logFileName = "\Install\Log\" + "Novartis_" + "Install_" + $logName + [System.String]::Format("{0}_{1}_{2}_{3}_",$depType, $dateSuffix, $timeSuffix,".csv")
[String]$csvFile2 = "\Install\Config\AppPool" + ".csv"
$csvFilePath2= GetFilePath $csvFile2 $currentDir
Import-Csv $csvFilePath2 -ErrorAction SilentlyContinue -ErrorVariable  csvErr | ForEach{
$ComputerNames=$_.ComputerNames.split(",")
$credentials=$_.Credentials
}
$logFilePath = GetFilePath $logFileName $currentDir 
CreateLogFile($logFilePath) 
Write-Host "Date: $dateSuffix" 
Write-Host "Setting Execution Policy :$ExecutionPolicy" (Get-Date)
Write-Host `n
Write-Host  "'****************************************************"  
Write-Host  "#------ $depType process started!------------------#"
 
Write-Host "****************************************************" 
Add-Content $logFilePath   "Date: $dateSuffix" 
Add-Content $logFilePath   "Setting Execution Policy :$ExecutionPolicy `n" 
Add-Content $logFilePath "`n"
Add-Content $logFilePath "`n"
Add-Content $logFilePath   "'****************************************************"  
Add-Content $logFilePath   "#------ $depType process started!------------------#"
 
Add-Content $logFilePath   "****************************************************" 


Write-Host "Input Values are:" $DepType $logName 
[String]$csvFile= $null
switch($DepType)
{
AddDeploy {

[String]$csvFile = "\Install\Config\AddDeploy" + ".csv"

}
Activate {
 
#Path for CSV File
[string]$csvFile = "\Install\Config\Activate" + ".csv"
 
}
Update {
 
#Path for CSV File
[string]$csvFile = "\Install\Config\Update" + ".csv"
 }
Remove {

[String]$csvFile = "\Install\Config\Remove" + ".csv"
}
Deactivate {
 
#Path for CSV File ** For Release
[string]$csvFile = "\Install\Config\Deactivate" + ".csv"

}
Uninstall {
#Path for CSV File ** For Release
[string]$csvFile = "\Install\Config\Uninstall" + ".csv"
}

default{
Write-Debug "The Command Line Arguments entered are invalid : $csvFile " 
Add-Content $logFilePath "The Command Line Arguments entered are invalid : $csvFile" 
}
}
#FilePath
$csvFilePath= GetFilePath $csvFile $currentDir

#  Checks If a File Exists

$isCsvFile = $csvFilePath
$FileExists = Test-Path $isCsvFile -ErrorAction SilentlyContinue -ErrorVariable isFileErr  -Include *.csv
If ($FileExists -eq $True) 
{
Write-Host '.' `n
Write-Host '.' `n
Write-Host '.' `n
Write-Host 'Process Started'
Add-Content $logFilePath "`n"
Write-Host "Choice: $DepType "
Add-Content $logFilePath "$DepType"
if($DepType -eq 'AddDeploy'-or 'Activate' -or 'Update' -or 'Remove' -or 'Deactivate' -or 'Uninstall')
{
Import-Csv $csvFilePath -ErrorAction SilentlyContinue -ErrorVariable  csvErr | ForEach{
if($DepType -eq 'AddDeploy')
{
[string]$solutionName= $_.SolutionName
[string]$ITUrl= $_.WebApplication
[bool]$Cas= [bool]::Parse($_.CASPolicies)
[bool]$GAC= [bool]::Parse($_.GACDeployment)
[bool]$isSandBox= [bool]::Parse($_.Sandbox)
[string]$siteCollectionName= $_.SiteCollectionName
}
if($DepType -eq 'Activate')
{
[string]$featureName= $_.FeatureName
[string]$featureID= $_.FeatureID
[string]$siteCollectionName= $_.SiteCollectionName
}
if($DepType -eq 'Update')
{
[string]$solutionName= $_.SolutionName
[string]$ITUrl= $_.WebApplication
[bool]$Cas= [bool]::Parse($_.CASPolicies)
[bool]$GAC= [bool]::Parse($_.GACDeployment)
[bool]$isSandBox= [bool]::Parse($_.Sandbox)
[string]$siteCollectionName= $_.SiteCollectionName
}
if($DepType -eq 'Remove')
{
[string]$solutionName= $_.SolutionName
[string]$ITUrl= $_.WebApplication
[bool]$Cas= [bool]::Parse($_.CASPolicies)
[bool]$GAC= [bool]::Parse($_.GACDeployment)
[bool]$isSandBox= [bool]::Parse($_.Sandbox)
[string]$siteCollectionName= $_.SiteCollectionName
}
if($DepType -eq 'Deactivate')
{
[string]$featureName= $_.FeatureName
[string]$featureID= $_.FeatureID
#[bool]$isFeatureDeactivation= [bool]::Parse($_.isFeatureDeactivation)
[string]$siteCollectionName= $_.SiteCollectionName
#[bool]$isFeaUninstallRequired= [bool]::Parse($_.isFeaUninstallRequired)
}
if($DepType -eq 'Uninstall')
{
[string]$featureName= $_.FeatureName
[string]$featureID= $_.FeatureID
#[bool]$isFeatureDeactivation= [bool]::Parse($_.isFeatureDeactivation)
[string]$siteCollectionName= $_.SiteCollectionName
#[bool]$isFeaUninstallRequired= [bool]::Parse($_.isFeaUninstallRequired)
}
}
Write-Host "`n"
#Check if the package exists
 
# $isPackageExisits= Test-Path $Path -ErrorAction SilentlyContinue -ErrorVariable isPkgExistsErr  -Include *.wsp
Add-Content $logFilePath "`n"
Add-Content $logFilePath "`n"
Add-Content $logFilePath "`n"
# 
Write-Host "`n"
Add-Content $logFilePath "`n"
Add-Content $logFilePath "`n"
Add-Content $logFilePath "`n"
switch ($DepType) 
{
AddDeploy {
$solution = Get-SPSolution $solutionName -ErrorAction SilentlyContinue -ErrorVariable solErr
#Get the Solution Path ***For Release
$solutionFilePath="\Install\Packages\"+$solutionName
$Path = GetFilePath $solutionFilePath $currentDir 
$isPackageExisits= Test-Path $Path -ErrorAction SilentlyContinue -ErrorVariable isPkgExistsErr  -Include *.wsp
if($isPackageExisits -eq $true)
{
StopAppPool $ComputerNames $credentials
AddSolution $solution $solutionName $Path $logFilePath $ITUrl $GAC $Cas
StartAppPool $ComputerNames $credentials
}
else
{
Write-Host "Package Does not exist...Kindly check the Package in the package folder or Config file : $solutionFilePath "
Add-Content $logFilePath  "Package  Does not exist...Kindly check the Package in the package folder or Config file : $solutionFilePath"
}
}
 
Activate{
$isFeature= Get-SPFeature -Site $siteCollectionName -ErrorAction SilentlyContinue -ErrorVariable isFeaErr
ActivateFeature $isFeature $featureName $featureID $siteCollectionName
}
 
Update{
#Get the Solution Path ***For Release
$solutionFilePath="\Install\Packages\"+$solutionName
$Path = GetFilePath $solutionFilePath $currentDir 
$isPackageExisits= Test-Path $Path -ErrorAction SilentlyContinue -ErrorVariable isPkgExistsErr  -Include *.wsp
if($isPackageExisits -eq $true)
{
$solution = Get-SPSolution $solutionName -ErrorAction SilentlyContinue -ErrorVariable solErr
StopAppPool $ComputerNames $credentials
UpdateSolution $solution $solutionName $Path $logFilePath $ITUrl $GAC $Cas
StartAppPool $ComputerNames $credentials
}
else
{
Write-Host "Package $solutionName Does not exist...Kindly check the Package in the package folder"
Add-Content $logFilePath  "Package $solutionName Does not exist...Kindly check the Package in the package folder"
}
}

Deactivate {
$FeatureActivated= Get-SPFeature -Site $siteCollectionName -ErrorAction SilentlyContinue -ErrorVariable featureActvErr
DeactivateFeatures $FeatureActivated $featureID $featureName $siteCollectionName     
}
Uninstall {
FeatureUninstall $featureID $featureName $SiteCollectionName
}
Remove {
$solution = Get-SPSolution $solutionName -ErrorAction SilentlyContinue -ErrorVariable solErr
#$solution,$solutionName,$Url,$logFilePath
StopAppPool $ComputerNames $credentials
UninstallRemoveSolution $solution $solutionName $ITUrl $logFilePath
StartAppPool $ComputerNames $credentials
}
default{ 
Write-Host "No Functions were Executed"
Add-Content $logFilePath "No Function Were Executed"
}
}

}

Write-Host "`n"
Write-Host "****************************"
Write-Host "$depType Process Completed"
Write-Host "****************************"
Add-Content $logFilePath "`n"
Add-Content $logFilePath "*****************************************"
Add-Content $logFilePath "$depType Process Completed"
Add-Content $logFilePath "*****************************************"
}
Else 
{
Write-Host "No file at this location" $isFileErr
Write-Host $isFileErr
Write-Host $isFeaErr
Add-Content $logFilePath "Input File Does Not Exist at Location: $isCsvFile"
Add-Content $logFilePath $isCsvFile
Add-Content $logFilePath $isFileErr
Add-Content $logFilePath $isFeaErr
}
if($csvErr -or $isFileErr -or $isFeaErr )
{
Write-Host "CSV File Command Error:" $csvErr
Add-Content $logFilePath "Error while processing  : $csvErr $isFileErr $isFeaErr"
Add-Content $logFilePath $isCsvFile
Add-Content $logFilePath $isFileErr
Add-Content $logFilePath $isFeaErr
}
Stop-SPAssignment -Global 
Remove-PsSnapin Microsoft.SharePoint.PowerShell

