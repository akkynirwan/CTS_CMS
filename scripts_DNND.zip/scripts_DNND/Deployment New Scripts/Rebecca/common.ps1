﻿#Param([String]$DepType,[String]$logName)

    #***********************************************Generic Functions**********************************************************************

#Function to Create the Logfile
function CreateLogFile
{
param($logFileNamePath)
try
{
write-output "***** Creating log file.." 
New-Item $logFileNamePath -type File -ErrorAction SilentlyContinue  -ErrorVariable fileErr  
if($fileErr)
{ 
Write-Host "Eror in creating a New Log file:" $fileErr 
Break
}
Set-Content $logFileNamePath "TimeStamp,SolutionName,DeploymentScope,Status,Result" -ErrorAction SilentlyContinue -ErrorVariable setErr
Write-Output "Log File created"
 
}
catch
{
if($setErr)
{
Write-Host "Error in Creating the Log File: $setErr"
}
}
Finally
{
}
}
#Function to Add the Snap In

function AddPowerShellSnapIn
{

try
{
$snapin = Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'} -ErrorVariable myErr -ErrorAction Inquire  
if ($snapin -eq $null) 
        {
           Write-Host "Loading SharePoint Powershell Snap-in"
       Add-PSSnapin "Microsoft.SharePoint.Powershell" -ErrorVariable snapErr -ErrorAction  Inquire 
}
if($myErr -or $snapErr )
{
  Write-Host "Error in Adding Powershell Snappin: " $myErr,$snapErr 
 
}
}
catch
 { 
   Write-Host "Error in Adding Powershell Snap In Function"
 } 
finally
{
}
}

#Function to Return the File Path
function GetFilePath
{
 
param ([String]$fileName,[String]$currentLocation)
try
{
  
#$file_Path= $currentLocation | split-path
return [String]$Path= $currentLocation + $fileName
}
catch
{
Write-Error "File Path Error:" $Error[0]
  
}
finally
{
}
}
 #Function to Stop App Pool
function StopAppPool
{
 
param ($ComputerNames,$cred)
try
{
  
foreach ($ComputerName in $ComputerNames)
{
Invoke-Command -ComputerName $ComputerName -ScriptBlock { Import-Module WebAdministration
$applicationPools = Get-ChildItem IIS:\AppPools | ? {$_.state -ne "Stopped"}
foreach($applicationPool in $applicationPools){
Write-host "Stopping application pool ""($($applicationPool.name)"""
$applicationPool.Stop() } } -credential $cred
Write-Host `n
Write-Host  "'****************************************************"  
Write-Host  "#------ Stopping Apppool at $ComputerName------------------#"
}
}
catch
{
Write-Error "File Path Error:" $Error[0]
  
}
finally
{
}
}
 #Function to Stop App Pool
function StartAppPool
{
 
param ($ComputerNames,$cred)
try
{
  
foreach ($ComputerName in $ComputerNames)
{
Invoke-Command -ComputerName $ComputerName -ScriptBlock { Import-Module WebAdministration
$applicationPools = Get-ChildItem IIS:\AppPools | ? {$_.state -ne "started"}
foreach($applicationPool in $applicationPools){
Write-host "Starting application pool ""($($applicationPool.name)"""
$applicationPool.Start() }} -credential $cred
Write-Host `n
Write-Host  "'****************************************************"  
Write-Host  "#------ Starting Apppool at $ComputerName------------------#"
}
}
catch
{
Write-Error "File Path Error:" $Error[0]
  
}
finally
{
}
}
#******************************Functions to add solution, activate features, Update Solution*********************************************
#Function to Add the solution
function AddSolution
{
Param($solution,$solutionName,$Path,$logFilePath,$ITUrl,$GAC,$Cas)
Try{
#Add the solution
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Adding the solution : $solutionName" 
if($solutionName)
{
#Checking if the solution exists
if($solution -eq  $null)
{
Add-Content $logFilePath "Adding the solution: $solutionName"
$solution = ADD-SPSolution -LiteralPath $Path -ErrorAction SilentlyContinue -ErrorVariable addSolErr
if($addSolErr)
{
Write-Host "Solution was not added: $solutionName" $addSolErr 
Add-Content $logFilePath "Solution $solutionName was not addedd : $addSolErr" 
}
else
{
while ( $solution.JobExists )
{
write-host "."
sleep 1
}
Write-Host "Solution Added: $solutionName " 
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution Added: $solutionName " 
}
   }
else
{
 Write-Host "Solution $solutionName Already Exists in the Solution Store"
 Add-Content $logFilePath "Solution $solutionName Already Exists in the Solution Store"
 
}
   #Deploy the solution
if (!$solution.ContainsWebApplicationResource)
{
Write-Host "Deploying solution $solutionName "
Write-Host '.'`n
Write-Host '.'`n
Write-Host '.'`n
Write-Host '.'`n
while ( $solution.JobExists )
{
write-host "."
sleep 1
}
       
Write-Host "Installing Solution to Farm : $solutionName"
Add-Content $logFilePath "Installing Solution to Farm : $solutionName"
           
$solution= Install-SPSolution -Identity $solutionName  -GACDeployment:$GAC -CASPolicies:$Cas -ErrorAction SilentlyContinue -ErrorVariable instSolErr -Confirm:$false -Force
if($instSolErr)
{ 
Write-Host "Solution $solutionName was not successfully installed " $instSolErr 
Add-Content $logFilePath "Solution $solutionName was not successfully installed: $instSolErr "
}
else
{
$deployed = $False
while ($deployed -eq $False) {
    sleep -s 2
    $s = Get-SPSolution -Identity $solutionName
    if ($s.Deployed -eq $True -And $s.JobExists -eq $False) {
        $deployed = $True
    }
    }

if(-not($instllErr))
{
Write-Host "Installed Solution Successful: $solutionName" 
Write-Host '.'`n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Installed Solution Successful: $solutionName " 
}
else
{ 
 
Write-Host "Solution $solutionName was not Deployed Successfully: $instllErr"
Add-Content $logFilePath "Solution $solutionName was not installed Successfully: $instllErr"
}
}
   } 
else
{
   Write-Host "Deploying solution $name to $_..."
$solution= Install-SPSolution -Identity $solutionName -WebApplication $ITUrl -GACDeployment:$gac -CASPolicies:$Cas -ErrorAction SilentlyContinue -ErrorVariable inSolErr -Confirm:$false -Force
if($inSolErr)
{
Write-Host "Solution $solutionName was not installed Successfully: $inSolErr"
Add-Content $logFilePath "Solution $solutionName was not installed Successfully: $inSolErr"
}
else
{
$deployed = $False
while ($deployed -eq $False) {
    sleep -s 2
    $s = Get-SPSolution -Identity $solutionName
    if ($s.Deployed -eq $True -And $s.JobExists -eq $False) {
        $deployed = $True
    }
    }

if(-not($instllErr))
{
Write-Host "Installed Solution Successful: $solutionName" 
Write-Host '.'`n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Installed Solution Successful: $solutionName " 
}
else
{ 
 
Write-Host "Solution $solutionName was not Deployed Successfully: $instllErr"
Add-Content $logFilePath "Solution $solutionName was not installed Successfully: $instllErr"
}
}
}
     
    

}
else
{
  Write-Host "The Solution Name is blank...Please check Your Config File"
  Add-Content $logFilePath  "The Solution Name is blank...Please check Your Config File"
 
}
}
catch
{
Write-Host "Error while adding/installing solution : $inSolErr $instSolErr "
Add-Content $logFilePath "Error while adding/installing solution : $inSolErr $instSolErr "
}
finally
{
}

}
# Function to Activate Features
function ActivateFeature
{
param ($isFeature,$featureName,$featureID,$siteCollectionName)

try
{
if($siteCollectionName)
{
        $spSite = new-object Microsoft.SharePoint.SPSite($siteCollectionName)
            if($featureID)
{
           if ($spSite.Features[$featureID] -eq $null) 
{
Write-Host `n
Add-Content $logFilePath "`n"
Write-Host " Enabling feature: $featureName / $featureID "
Write-Host `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath " Enabling feature: $featureName / $featureID"
 
  $status= Enable-SPFeature  -Identity $featureID -Url $siteCollectionName -ErrorAction SilentlyContinue -ErrorVariable actFeaErr -Confirm:$false
if($actFeaErr)
{
    Write-Host `n
Add-Content $logFilePath "`n"
Write-Host "Error while Activating Feature $featureName \ $featureID : $actFeaErr"
Write-Host `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Error While Activating Feature $featureName $featureID : $actFeaErr"
}
else
{
while($status.JobExists)
{
write-host "."
sleep 1
}
 
Write-Host `n
Add-Content $logFilePath "`n"
Write-Host " Feature $featureName / $featureID  Activated Successfully"
Write-Host '.'`n
Write-Host `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Feature $featureName / $featureID Activated Successfully"
}
}
else
{
Write-Host "feature $featureName / $featureID already activated"
}
}
else
{
Write-Host "Feature ID is  Blank: $featureID"
Add-Content $logFilePath "Feature ID is Blank : $featureID"
}
}
else
{
Write-Host "Site Collection Name is Blank: $siteCollectionName"
Add-Content $logFilePath "Site Collection Name is Blank: $siteCollectionName"
}
}
catch
{
 Write-Host `n
 Add-Content $logFilePath "`n"
 Write-Host 'Error While Activating Feature: $featureName $featureID ' $actFeaErr
 Add-Content $logFilePath "Error While Activating Feature: $featureName $featureID $actFeaErr "
}
finally
{
$spSite.Dispose();

}
}

Function UpdateSolution
{
param($solution,$solutionName,$Path,$logFilePath,$ITUrl,$GAC,$Cas)
try
{
#Update the solution
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Updating the solution : $solutionName" 
   #$solution = Add-SPSolution $path
#Checking if the solution exists
if($solution)
{
Add-Content $logFilePath "Updating the solution: $solutionName"
if(-not($solutionName ))
{
  Write-Host "The Solution Name is blank...Please check Your Config File"
  Add-Content $logFilePath  "The Solution Name is blank...Please check Your Config File"
  return
}
else
{
$solution = Update-SPSolution –Identity $solutionName -LiteralPath $Path -ErrorAction SilentlyContinue -ErrorVariable updateSolErr -GACDeployment:$GAC   
}
$deployed = $False
while ($deployed -eq $False) {
    sleep -s 2
    $s = Get-SPSolution -Identity $solutionName
    if ($s.Deployed -eq $True -And $s.JobExists -eq $False) {
        $deployed = $True
    }
    }

if($updateSolErr)
{
Write-Host "Solution was not Updated: $solutionName" $updateSolErr 
Add-Content $logFilePath "Solution $solutionName was not Updated : $updateSolErr" 
}
else
{
Write-Host "Solution Updated: $solutionName " 
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution Updated: $solutionName " 
}
   }
else
{
 Write-Host "Solution is not present for update to proceed "
 Add-Content $logFilePath "Solution $solutionName Solution is not present for update to proceed"
}
  
}
catch
{
Write-Host "Error while updating the solution  $updateSolErr"
Add-Content $logFilePath "Error while updating the solution $updateSolErr"
}
finally
{
}
}
#**********************************************************************************************************************************
#Functions to Remove Solution,Deactivate Features
function DeactivateFeatures
{
 
param($featureActivated,$featureID,$featureName,$SiteCollectionName)
try
{
if($siteCollectionName)
{
$spSite = new-object Microsoft.SharePoint.SPSite($siteCollectionName)
          
  if($featureID)
  {
   if ($spSite.Features[$featureID] -ne $null) 
{
Write-Host "Disabling Feature: $featureName"
Write-Host '....' `n
Write-Host '...' `n
Add-Content $logFilePath "Disabling Feature: $featureName" 
Add-Content $logFilePath "`n"
Add-Content $logFilePath "......"
Add-Content $logFilePath "...."
Add-Content $logFilePath ".."
$status= Disable-SPFeature -Identity $featureID -Url $SiteCollectionName -ErrorAction SilentlyContinue -ErrorVariable disFeaErr  -force -Confirm:$false 
if($disFeaErr)
{
Write-Host '......' `n
Add-Content $logFilePath "`n"
Write-Error "Error While Disabling the Feature: $disFeaErr" 
Write-Host '......' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Error While Disabling the Feature: $disFeaErr"
 
}
else
{
while($status.JobExists)
{
write-host "."
sleep 1
}
Write-Host "Feature Disabled Successfully:" $featureName
Write-Host '......' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Feature Disabled Successfully: $featureName"
}
 
}

else
{
Write-Host "Feature is not activated at site collection : $siteCollectionName"
Add-Content $logFilePath "Feature is not activated at site collection  : $siteCollectionName"
Write-Host "Deactivating at web level"
$web=Get-SPWeb -Identity $SiteCollectionName
Write-Host $web
Disable-SPFeature -Identity $featureID -Url $web.Url -ErrorAction SilentlyContinue -ErrorVariable disFeaErr  -force -Confirm:$false
}
 
}
else
{
Write-Host "Feature ID is Blank : $FeatureID"
Add-Content $logFilePath "Feature ID is blank : $FeatureID"
}
}
else
{
Write-Host "SiteCollection URL is blank : $siteCollectionName"
Add-Content $logFilePath "SiteCollection URL is blank : $siteCollectionName"
}
}
Catch
{
Write-Host "Erorr while Deactivating Feature $featureName : $disFeaErr  "
Write-Host '......' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Erorr while Deactivating Feature $featureName : $disFeaErr  "
}
Finally
{
$spSite.Dispose()
}
}
function FeatureUninstall
{
param($featureID,$featureName,$SiteCollectionName)
try
{
if($siteCollectionName)
{
$spSite = new-object Microsoft.SharePoint.SPSite($siteCollectionName)
          
  if($featureID)
  {
   if ($spSite.Features[$featureID] -eq $null) 
{
$status= Uninstall-SPFeature -Identity $featureID -ErrorAction SilentlyContinue -ErrorVariable unInstFeaErr -force -confirm:$false
}
else
{
Write-Host "Feature $featureName / $featureID ....Cannot uninstall feature at this time...Please check the feature activation/deactivation status"
Add-Content $logFilePath "Feature $featureName / $featureID ....Cannot uninstall feature at this time...Please check the feature activation/deactivation status"
return
}
if($unInstFeaErr)
{
Write-Host `n
Add-Content $logFilePath "`n"
Write-Host "Error while Uninstalling the feature $featureName"
Add-Content $logFilePath "Error while Uninstalling the feature $featureName"
Write-Host `n
Add-Content $logFilePath "`n"
}
else
{
 
while($status.JobExists)
{
write-host "."
sleep 1
}
Write-Host `n
Add-Content $logFilePath "`n"
Write-Host "Feature $featureName / $featureID Uninstalled Successfully"
Add-Content $logFilePath "Feature $featureName / $featureID Uninstalled Successfully"
Write-Host `n
Add-Content $logFilePath "`n"
}
}
}
 
else
{
Write-Host "Site Collection Name is Blank: $siteCollectionName "
Add-Content $logFilePath "Site Collection Name is Blank: $siteCollectionName "
}
}
catch
{
}
finally
{
#$spSite.Dispose()
}
}
#Function to Uninstall/Remove/delete the Installed Solution
function UninstallRemoveSolution
{
 
param ($solution,$solutionName,$Url,$logFilePath)
try
{
if ($solution -ne $null)
{
       #Retract the solution
       if ($solution.Deployed)
{
Write-Host "Retracting solution: $solutionName "
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Retracting Solution: $solutionName " 
if($solution.ContainsWebApplicationResource)
{
if(-not($solutionName))
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Solution Name is blank...Please check the config file"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution Name is blank...Please check the config file"
return
}
else
{
#Uninstall-SPSolution -Identity $_.SolutionName -WebApplication $_.ITUrl -Confirm:$false
Uninstall-SPSolution -Identity $solutionName -WebApplication  $Url -ErrorAction SilentlyContinue -ErrorVariable solErr -Confirm:$false
}
if($solErr)
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Error While Uninstalling $solutionName from Web Application: $solErr"
Add-Content $logFilePath "Error While $solutionName Solution from Web Application: $solErr" 
}
else
{
Write-Host "Solution Retracted: $solutionName"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Retracted Solution From Webapplication : $solutionName"
}
   }  
else
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Retracting the Solution $solutionName from Farm "
if(-not($solutionName))
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Solution Name is blank...Please check the config file"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution Name is blank...Please check the config file"
return
}
else
{
#Uninstall-SPSolution -Identity $_.SolutionName -Confirm:$false
Uninstall-SPSolution -Identity $solutionName -Confirm:$false -ErrorAction SilentlyContinue -ErrorVariable sol_Err
}
if($sol_Err)
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Error while Retracting the $solutionName from Farm : $sol_Err"
Add-Content $logFileName "Error while Retracting $solutionName from Farm : $sol_Err"
 
}
else
{
 
#Add-Content $logFilePath "Solution retracted"
   #Block until we're sure the solution is no longer deployed.
   do 
{ 
Start-Sleep 2 
} 
while(!((Get-SPSolution $solutionName -ErrorAction SilentlyContinue -ErrorVariable instllErr).Deployed))
if(-not($instllErr))
{
Write-Host "Farm Solution Retracted Successfully: $solutionName"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Farm Solution Retracted Successfully: $solutionName"
}
else
{
Write-Host "The Solution was not Retracted: $instllErr"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "The Solution was not Retracted: $instllErr"
}
}
}
   
}
#Delete the solution
while ( $solution.JobExists )
{
write-host "."
sleep 2
}
if ($solution.Deployed -eq $false)
{
         
Write-Host "Removing solution : $solutionName" 
if(-not($solutionName))
{
 
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Solution Name is blank...Please check the config file"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution Name is blank...Please check the config file"
return
}
else
{
       #Get-SPSolution $_.SolutionName | Remove-SPSolution -Confirm:$false
Remove-SPSolution -Identity $solutionName -force -Confirm:$false -ErrorAction SilentlyContinue -ErrorVariable remSolErr
}
if($remSolErr)
{
Write-Host 'Error while Removing $solutionName : $remSolErr'
Add-Content $logFilePath "Error while Removing $solutionName : $remSolErr" 
}
 
else
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host "Solution $solutionName Removed Successfully"
Write-Host '.' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution $solutionName Was Succefully Removed"
}
}
}
else
{
Write-Host "Solution $solutionName is not installed"
Write-Host '......' `n
Add-Content $logFilePath "`n"
Add-Content $logFilePath "Solution $solutionName is not installed"
}
}
catch
{
Write-Host '.' `n
Add-Content $logFilePath "`n"
Write-Host " Error while Uninstalling/Removing the Solution $solutionName : $sol_Err $remSolErr"
Add-Content $logFilePath " Error while Uninstalling/Removing the Solution $solutionName : $sol_Err $remSolErr"
}
Finally
{
}
}
