﻿#Load SharePoint User Profile assemblies 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Office.Server") 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.Office.Server.UserProfiles") 
  

 $profileApp = @(Get-SPServiceApplication | ?  {$_.TypeName -eq "User Profile Service Application"})[0] 
 $serviceContext = [Microsoft.SharePoint.SPServiceContext]::GetContext($profileApp.ServiceApplicationProxyGroup, [Microsoft.SharePoint.SPSiteSubscriptionIdentifier]::Default) 

  
#Get UserProfileManager  
$userProfileConfigManager = New-Object Microsoft.Office.Server.UserProfiles.UserProfileConfigManager($serviceContext) 
$userProfilePropertyManager = $userProfileConfigManager.ProfilePropertyManager 
$userProfileTypeProperties = $userProfilePropertyManager.GetProfileTypeProperties([Microsoft.Office.Server.UserProfiles.ProfileType]::User) 
$userProfilePropertyManager = $userProfilePropertyManager.GetCoreProperties()
$userProfileSubTypeManager = [Microsoft.Office.Server.UserProfiles.ProfileSubTypeManager]::Get($serviceContext) 
$userProfile = $userProfileSubTypeManager.GetProfileSubtype([Microsoft.Office.Server.UserProfiles.ProfileSubtypeManager]::GetDefaultProfileName([Microsoft.Office.Server.UserProfiles.ProfileType]::User)) 
$userProfileProperties = $userProfile.Properties 
 
$PropertiesTocreate = Import-Csv "E:\Prooperties.csv"

foreach($propTocreate in $PropertiesTocreate)
{
$prop = $userProfileProperties.GetPropertyByName($propTocreate.Name)  
if( $prop -eq $null)
{
Try{
#Set Custom Property values 

$PropertyName = $propTocreate.Name 
$PropertyDisplayName = $propTocreate.DispalyName  
$Privacy=$propTocreate.Privacy 
$PrivacyPolicy=$propTocreate.PrivacyPolicy 

Add-Content "E:\logupsa.txt" -Value "Creating field $PropertyDisplayName"
Write-Host "Creating field $PropertyDisplayName"

$coreProperty = $userProfilePropertyManager.Create($false) 
$coreProperty.Name = $PropertyName 
$coreProperty.DisplayName = $PropertyDisplayName 
$coreProperty.Type = $propTocreate.Type
$coreProperty.Length = "250"
  
#Add Custom Property 
$userProfilePropertyManager.Add($coreProperty) 
$profileTypeProperty = $userProfileTypeProperties.Create($coreProperty) 

Add-Content "E:\logupsa.txt" -Value "Core Property Created"
  
#Display Settings 
  
#Show on the Edit Details page 
$profileTypeProperty.IsVisibleOnEditor = $true 
  
#Show in the profile properties section of the user's profile page 
$profileTypeProperty.IsVisibleOnViewer = $true 
  
#Show updates to the property in newsfeed 
$profileTypeProperty.IsEventLog = $true 
  
$userProfileTypeProperties.Add($profileTypeProperty) 
$profileSubTypeProperty = $userProfileProperties.Create($profileTypeProperty) 
$profileSubTypeProperty.DefaultPrivacy =[Microsoft.Office.Server.UserProfiles.Privacy]::$Privacy 
$profileSubTypeProperty.PrivacyPolicy = 
[Microsoft.Office.Server.UserProfiles.PrivacyPolicy]::$PrivacyPolicy 
$userProfileProperties.Add($profileSubTypeProperty)

Add-Content "E:\logupsa.txt" -Value "Created Property $PropertyDisplayName"
Write-Host "Created Property field $PropertyDisplayName"

}
catch
{
$ErrorMessage = $_.Exception.Message

Add-Content "E:\logupsa.txt" -Value $ErrorMessage
}
}
#else
#{
#try
#{
 #$userProfilePropertyManager.RemovePropertyByName($prop.Name)
# $property.CoreProperty.Length = "255"
 #$property.CoreProperty.Commit()
 #$propname = $prop.Name
#Add-Content "E:\logupsa.txt" -Value "Property deleted for $propname"
#Write-Host "Property deleted $propname"  
 #}
 #Catch
 #{
 #$ErrorMessage = $_.Exception.Message

#}
#}
}