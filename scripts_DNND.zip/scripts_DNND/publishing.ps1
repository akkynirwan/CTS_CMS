Add-PSSnapin Microsoft.SharePoint.PowerShell �erroraction SilentlyContinue
$filePath="D:\Temp\Chhaya\publishingSites.txt"
$webTemplate ="NOVARTIS.INTRANET.PUBLISHING#0"
$webapps = Get-Spwebapplication
foreach ($webapp in $webapps)
{

$sites = $webapp.Sites
foreach ($site in $sites)
{
    try
    {
        $web=$site.rootweb
                if ($web.WebTemplate -eq $webTemplate) # or use ($web.WebTemplate -eq &quot;STS&quot;)
                {
                    Write-Host $web.Url
                    $web.Url | Out-File -FilePath $filePath -Append -Width 256
                }
            }
            finally
            {
                $web.Dispose();
            }
            $site.Dispose();
        }

            
        }