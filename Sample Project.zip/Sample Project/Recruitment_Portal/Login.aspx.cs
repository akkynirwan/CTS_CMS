﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user_id"] != null)
        {
            Response.Redirect("home_"+Session["type"]+".aspx");
        }
        
    }
    protected void Login_Button_Click(object sender, EventArgs e)
    {
        BL b = new BL();
        bool res = b.validate_user(Username_TextBox.Text, Password_TextBox.Text);
        Alert alert = new Alert();
        if (res == true )
        {
          string type = b.user_type(Username_TextBox.Text);
         
          Session["user_id"] = Username_TextBox.Text.ToString();
          Session["type"] = type;
          
          if (type.ToLower().Equals("admin"))
          {
            
              alert.callAlert("success_login_admin", "Login", "Login Successful");
             // Response.Redirect("home_admin.aspx");
       // Response.Write("<script>window.location.href='home_admin.aspx';</script>");
              //alert('Login Successful...');
          }
          else if (type.ToLower().Equals("seller")) {
              alert.callAlert("success_login_seller", "Login", "Login Successful");
             // Response.Write("<script>alert('Login Successful...');window.location.href='home_seller.aspx';</script>");
          }
           // Panel1_ModalPopupExtender.Show();
        }
        else
        {
            alert.callAlert("warning", "Login", "Login Successful");
          //  Response.Write("<script>alert('Login Failed...Try again')</script>");
            Username_TextBox.Text = "";
            Password_TextBox.Text = "";
            Username_TextBox.Focus(); //write cursor focus automatically on Username TextBox
        }
    }
//    protected void Button1_Click(object sender, EventArgs e)
//    {
        
//      //  Session["user_id"] = Username_TextBox.Text.ToString();
//        //Navigate to Candidate_Display.aspx
////Response.Redirect("home_admin.aspx");
//    }
    
}