﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        BL b = new BL();
        
       
        if (!IsPostBack)
        {
            if (Session["user_id"] != null)
            {
                user_id.Text = Session["user_id"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");

            }
        }
        

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string m = con_category.SelectedItem.Text;
        Panel1.Visible = true;
       
    }
    
}