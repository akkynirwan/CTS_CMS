﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["user_id"] != null)
            {
                user_id.Text = Session["user_id"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");

            }
        }
    }

   
    protected void Button1_Click1(object sender, EventArgs e)
    {
        BL b = new BL();
        GridView2.SelectRow(0);
        int res = b.approved_contract(GridView2.SelectedRow.Cells[1].Text);
        int res2 = b.approved_contract_amenities(GridView2.SelectedRow.Cells[1].Text);
        Alert alert = new Alert();
        if (res > 0 && res2 > 0) //successful
        {
            alert.callAlert("success_approved", "Approve", "Contract Approved");
           // Response.Write("<script>alert('Contract Approved...');window.location.href='approve_contract.aspx';</script>");
        }
        else
        {
            alert.callAlert("warning", "Contract", "Not Successful");
           // Response.Write("<script>alert('Error Occured.. \n');window.location.href='approve_contract.aspx';</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        BL b = new BL();
        GridView2.SelectRow(0);

        b.reject_contract(GridView2.SelectedRow.Cells[1].Text);
        b.reject(GridView2.SelectedRow.Cells[1].Text);
        //GridView2.SelectRow(0);
        //int res = b.approved_contract(GridView2.SelectedRow.Cells[1].Text);
        //int res2 = b.approved_contract_amenities(GridView2.SelectedRow.Cells[1].Text);
     
        Alert alert = new Alert();
        alert.callAlert("rejected_approved", "Approve", "Contract Approved");
    }
}