﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;
using System.Data.SqlClient;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {



        if (!IsPostBack)
        {


            if (!IsPostBack)
            {
                if (Session["user_id"] != null)
                {
                    user_id.Text = Session["user_id"].ToString();
                }
                else
                {
                    Response.Redirect("login.aspx");

                }
            }

            try
            {
                
                BL b = new BL();
                DataTable dt = b.display_updated_data_BL(user_id.Text);
                //Binfd data fetched under datatable with TextBox Controls
                foreach (DataRow dr in dt.Rows)
                {

                    //first_name.Text = dr["first_name"].ToString();
                    first_name.Text=(dr["first_name"].ToString());
                    middle_name.Text = dr["middle_name"].ToString();
                    last_name.Text = dr["last_name"].ToString();
                   
                               
                    //  PinCode_TextBox.Text = dr["pincode"].ToString();
                    contact.Text = dr["contact_number"].ToString();
                    email.Text = dr["email_id"].ToString();
                    address.Text = dr["address"].ToString();
                   
                    // Guardian_textBox.Text = dr["father name"].ToString();
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }



        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Alert alert = new Alert();
        try
        {
            BL b = new BL();
            int res = b.edit_user_details("1",first_name.Text,middle_name.Text,last_name.Text,contact.Text,email.Text,address.Text);
            if (res > 0) //registration is successful
            {
                alert.callAlert("success_edit", "Login", "Login Successful");
                //Response.Write("<script>alert('Update Successful');window.location.href='login.aspx'</script>");
                //email section
            }
            else
            {
                alert.callAlert("warning", "Login", "Login Successful");
                //Response.Write("<script>alert('Update Unsuccessful')</script>");
            }

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}