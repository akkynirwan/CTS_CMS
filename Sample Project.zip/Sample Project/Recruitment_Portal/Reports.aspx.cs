﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (RadioButton1.Checked != true)
        {
            GridView1.Visible = false;
        }
        //else {
        //    GridView1.Visible = true;
        //}
        if (RadioButton2.Checked != true)
        {
            GridView2.Visible = false;
        }
        if (RadioButton3.Checked != true)
        {
            GridView3.Visible = false;
        }
        if (RadioButton4.Checked != true)
        {
            GridView4.Visible = false;
        }
        //GridView2.Visible = false; GridView3.Visible = false;
        //GridView4.Visible = false;
    }
       
           
    
      
    
  
    

   
protected void RadioButton1_CheckedChanged1(object sender, EventArgs e)
{
    GridView2.Visible = false;
    GridView3.Visible = false; GridView4.Visible = false;
            GridView1.Visible = true;
}
protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
{
    GridView1.Visible = false; GridView3.Visible = false; GridView4.Visible = false;
            GridView2.Visible = true;
}
protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
{
    GridView1.Visible = false; GridView2.Visible = false; GridView4.Visible = false;
    GridView3.Visible = true;
}
protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
{
    GridView1.Visible = false; GridView2.Visible = false; GridView4.Visible = false;
    GridView3.Visible = false;
    GridView4.Visible = true;
}
}