﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

using Candidate_BL;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }
    //protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    //{
    //    try
    //    {
    //        //Registration Code
    //        Random rd = new Random();
            

            

    //        string user_id = "1234";
    //        DateTime dt=Calendar1.SelectedDate.Date;
    //        string gen=string.Empty;
    //        string ty=string.Empty;

    //        if (male.Checked) {gen=male.Text;}
    //        else{gen=female.Text;}
            
    //       if (RadioButton3.Checked) {ty=RadioButton3.Text;}
    //        else{ty=RadioButton3.Text;}

    //        BL b = new BL();

    //        int res = b.registration(user_id, fname.Text, mname.Text, lname.Text, dt, gen, cnumber.Text, email.Text,address.Text, citycode.Text, ty, countrycode.Text);

    //        if (res > 0) //registration is successful
    //        {
    //            Response.Write("<script>alert('Registration Successful...Your User id= " + user_id + "');window.location.href='Candidate_Login.aspx';</script>");
    //        }
    //        else
    //        {
    //            Response.Write("<script>alert('Registration Unsuccessful')</script>");
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Response.Write(ex.Message);
    //    }

    //}
    //protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    //{

    //}
    protected void Retype_Password_TextBox_TextChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Registration Code
            Random rd = new Random();




            string user_id = Convert.ToString(rd.Next(1000,9999));
            DateTime dt = DateTime.ParseExact(dob.Text, "yyyy-MM-dd", null);
            string gen = string.Empty;
            string ty = string.Empty;
            string pwd=password.Text;
            if (male.Checked) { gen = "M"; }
            else { gen = "F"; }

            if (RadioButton3.Checked) { ty = RadioButton3.Text; }
            else { ty = RadioButton4.Text; }

            BL b = new BL();

            int res = b.registration(user_id, fname.Text, mname.Text, lname.Text, dt, gen, cnumber.Text, email.Text, address.Text, citycode.Text, ty, countrycode.Text);
            int cred=b.credentials(user_id,pwd);
            Alert alert = new Alert();
            if ((res >0 && cred >0)) //registration is successful
            {
              
                
               Response.Write("<script>alert('Registration Successful...Your User id= " + user_id + "');window.location.href='Login.aspx';</script>");
            }
            else
            {
                alert.callAlert("warning", "Registration", "Registration Not Successful");
                //Response.Write("<script>alert('Registration Unsuccessful')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
    protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}