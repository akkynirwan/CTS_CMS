﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["user_id"] != null)
        {
            user_id.Text = Session["user_id"].ToString();
            cid.Text = Session["user_id"].ToString();
        }
        else
        {
            Response.Redirect("home_admin.aspx");

        }
       
   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Registration Code
          
            string contractor_login_id = Session["user_id"].ToString();
         
            string cat = con_category.SelectedItem.Text;
            string cname = contract_name.Text;
            string dat = start_date.Text;
           
            DateTime st_dt = DateTime.ParseExact(dat, "yyyy-MM-dd", null);
           
            int valid = Convert.ToInt32(validity.Text);
         
           DateTime et_dt = st_dt.AddYears(valid);
            string status = "pending";
            string tc = terms.Text;
            
            BL b = new BL();

            int res = b.create_contract(contractor_login_id, cname, cat, st_dt, et_dt, status, tc);
            Alert alert = new Alert();  
            

            if (res > 0 ) //successful
            {
                alert.callAlert("create_contract", "Login", "Contract Created");
                //  Response.Write("<script>alert('Contract Created Successfully...');window.location.href='home_admin.aspx';</script>");
            }
            else
            {
                alert.callAlert("warning", "Contract", "Not Successful");
               // Response.Write("<script>alert('Opps.. \n Contract Cannot be Created')</script>");
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}