﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Candidate_BL;
using System.Text;

public partial class _Default : System.Web.UI.Page
{
    StringBuilder sb = new StringBuilder();

    //public void setChb_Data(CheckBox chb)
    //{
    //    if (chb.Checked.Equals(true))
    //    {
    //        sb.Append(chb.Text);
    //    }
        
    //}
    string id = "0";
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            if (Session["user_id"] != null)
            {
                user_id.Text = Session["user_id"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");

            }
        }
        GridView1.SelectRow(0);
       string cat_type=GridView1.SelectedRow.Cells[4].Text;
      
        

       if (cat_type.ToLower().Equals("furniture")) {
           Amenity1.Text = "Closet";
        
           Amenity2.Text = "Bed";
          
           Amenity3.Text = "Side Table";
           
           Amenity4.Text = "Mirror table";
           
           Amenity5.Text = "Dining Table";
         

           id = "CAT00001";
           
       }

       if (cat_type.ToLower().Equals("food"))
       {
           Amenity1.Text = "Chinese"; Amenity2.Text = "Desert"; Amenity3.Text = "Indian"; Amenity4.Text = "Mexican"; Amenity5.Text = "Thai"; id = "CAT00002";

       }
       if (cat_type.ToLower().Equals("room"))
       {
           Amenity1.Text = "AC"; Amenity2.Text = "Honeymoon Suite"; Amenity3.Text = "Deluxe"; Amenity4.Text = "Super Deluxe"; Amenity5.Text = "Premium";
           id = "CAT00003";
       }
       if (cat_type.ToLower().Equals("golf"))
       {
           Amenity1.Text = "Clubs"; Amenity2.Text = "Bags"; Amenity3.Text = "Golf Cart"; Amenity4.Text = "Caddie"; Amenity5.Text = "Ball";
           id = "CAT00004";
       }

       if (cat_type.ToLower().Equals("lunch"))
       {
           Amenity1.Text = "Buffet"; Amenity2.Text = "A la Carte"; Amenity3.Text = "Barbeque"; Amenity4.Text = "Veg"; Amenity5.Text = "Non-Veg";
           id = "CAT00005";
       }


    

       
       
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        BL b = new BL();
        string feed = feedback.Text;
        Alert alert = new Alert();
        DateTime dt = DateTime.Now;
        

    
        StringBuilder sb = new StringBuilder();
       
        if (amenities_other.Text.Trim().Length > 0) {
            sb.Append(amenities_other.Text);
            sb.Append(",");
        }

        if(Amenity1.Checked.Equals(true)){
          sb.Append(Amenity1.Text);
          sb.Append(",");
        }
          if(Amenity2.Checked.Equals(true)){
          sb.Append(Amenity2.Text);
          sb.Append(",");
        }
          if(Amenity3.Checked.Equals(true)){
          sb.Append(Amenity3.Text);
          sb.Append(",");
        }
          if(Amenity4.Checked.Equals(true)){
          sb.Append(Amenity4.Text);
          sb.Append(",");
        }
          if(Amenity5.Checked.Equals(true)){
          sb.Append(Amenity5.Text);
        }
          
          int l = sb.Length;
          string amenities=sb.ToString().Substring(l - 1, 1);
          
       int res= b.insert_amenities(GridView1.SelectedRow.Cells[1].Text, user_id.Text,
              "Locked", id, feed, dt, amenities);
       int res2 = b.update_contract(GridView1.SelectedRow.Cells[1].Text);

       if (res > 0 && res2 > 0 ) //registration is successful
       {
           alert.callAlert("success_lock", "Contract Locked", "Contract Locked");
           //Response.Write("<script>alert('Contract Locked...');window.location.href='home_seller.aspx';</script>");
       }
       else
       {
           alert.callAlert("warning", "Contract", "Not Successful");
           //Response.Write("<script>alert('Please Try Again');</script>");
       }
       
    }
    protected void Amenity1_CheckedChanged(object sender, EventArgs e)
    {

    }
}