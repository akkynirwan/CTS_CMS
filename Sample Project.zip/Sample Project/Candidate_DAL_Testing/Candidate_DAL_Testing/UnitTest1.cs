﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DAL_Library;

namespace Candidate_DAL_Testing
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void User_Id_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("SAGO1234", "dave@123", "dave", "NA",
                "huges","dave@gmail.com", 9600197755);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void Password_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("DAHU1235", "sam@123", "dave", "NA",
                "huges", "dave@gmail.com", 9600197755);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void First_Name_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("DAHU1235", "dave@123", null, "NA",
                 "huges", "dave@gmail.com", 9600197755);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void Last_Name_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("DAHU1235", "dave@123", "dave", "NA",
                 null, "dave@gmail.com", 9600197755);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void Email_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("DAHU1235", "dave@123", "dave", "NA",
                 "huges", "sam@gmail.com", 9600197755);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void Phone_Test()
        {
            Candidate_DAL d = new Candidate_DAL();
            int i = d.registration("DAHU1235", "dave@123", "dave", "NA",
                 "huges", "dave@gmail.com", 9600197756);
            Assert.AreEqual(1, i);
        }
        [TestMethod]
        public void User_Data_Credentials()
        {

        }
    }
}
