﻿using System;
//Namespace for Ado.Net
using System.Data.SqlClient;
using System.Data;

namespace DAL_Library //Do not remove the namespace
{
    public class Candidate_DAL
    {
        public string connection = "Data Source=PC190305\\MSSQLSERVER2008;Initial Catalog=cms;Integrated Security=True";

        public int registration(string login_id, string f_name,
             string middle_name, string last_name, DateTime dob, string gender,
            string contact_number, string email_id, string address, string city_code, string type, string country_code)
        {
            //ADO.NET FOR INSERT
            //(i)connection path to connect with SQL Server
            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("insert_in_registration", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@login_id", login_id);
                cmd.Parameters.AddWithValue("@first_name", f_name);
                cmd.Parameters.AddWithValue("@middle_name", middle_name);
                cmd.Parameters.AddWithValue("@last_name", last_name);
                cmd.Parameters.AddWithValue("@dob", dob);
                cmd.Parameters.AddWithValue("@gender", gender);
                cmd.Parameters.AddWithValue("@contact_number", contact_number);
                cmd.Parameters.AddWithValue("@email_id", email_id);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@city_code", city_code);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@country_code", country_code);

                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }

        }



        public int create_contract(string contractor_login_id, string contract_name,
           string contract_category, DateTime start_date, DateTime end_date, string status,
           string terms)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("insert_contract", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contractor_login_id", contractor_login_id);
                cmd.Parameters.AddWithValue("@contract_name", contract_name);
                cmd.Parameters.AddWithValue("@contract_category", contract_category);
                cmd.Parameters.AddWithValue("@start_date", start_date);
                cmd.Parameters.AddWithValue("@end_date", end_date);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@terms_and_conditions", terms);

                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }

        }

















        public int credentials(string login_id, string password
            )
        {
            //ADO.NET FOR INSERT
            //(i)connection path to connect with SQL Server
            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("insert_in_password", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@login_id", login_id);
                cmd.Parameters.AddWithValue("@password", password);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }

        }





        public DataTable login_data(string username, string password)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {

                con.Open();

                SqlCommand cmd = new SqlCommand("insert_password", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@login_id", username);
                cmd.Parameters.AddWithValue("@password", password);
                //Call all records present in the table through data adapter
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                //Create temporary storage location to store the data on client side
                DataSet ds = new DataSet();
                //Fill dataset with records that you have extracted via data adapter
                //Data Adapter uses Fill() method to insert all the extracted
                //data inside data set
                da.Fill(ds);

                DataTable dt = ds.Tables[0]; //1 Row will be extracted
                //if credentials matches
                return dt;




            }
        }

        public DataTable user_type_dal(string username)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {

                con.Open();

                SqlCommand cmd = new SqlCommand("login_type", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@login_id", username);

                //Call all records present in the table through data adapter
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                //Create temporary storage location to store the data on client side
                DataSet ds = new DataSet();
                //Fill dataset with records that you have extracted via data adapter
                //Data Adapter uses Fill() method to insert all the extracted
                //data inside data set
                da.Fill(ds);

                DataTable dt = ds.Tables[0]; //1 Row will be extracted
                //if credentials matches
                return dt;




            }
        }


        public int insert_amenities(string contract_id, string supplier_id,
          string contract_satus, string category_id, string feedback, DateTime status_recent_update_date, string amenities_features)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("insert_amenities", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);
                cmd.Parameters.AddWithValue("@supplier_id", supplier_id);
                cmd.Parameters.AddWithValue("@contract_status", contract_satus);
                cmd.Parameters.AddWithValue("@category_id", category_id);
                cmd.Parameters.AddWithValue("@feedback", feedback);
                cmd.Parameters.AddWithValue("@status_recent_update_date", status_recent_update_date);
                cmd.Parameters.AddWithValue("@amenities_features", amenities_features);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0
            }

        }








        public int contract_update_status(string contract_id)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("update_status", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0


            }

        }



        public int contract_approved_status(string contract_id)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("approved_status", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0


            }

        }



        public int contract_approved_status_amenities(string contract_id)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("approved_contract_status", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0


            }

        }


        public int edit_user_details(string login_id,string first_name, string middle_name,
            string last_name, string contact_number, string email_id,
            string address)
        {

              using (SqlConnection con = new SqlConnection(connection))
            {
            con.Open();

            //Write SQL Command for Insert
            //Call Stored proc for insert
            SqlCommand cmd = new SqlCommand("update_user_details", con);

            //What is insert_data?
            cmd.CommandType = CommandType.StoredProcedure;

            //Supply data to the parameters of stored proc
            cmd.Parameters.AddWithValue("@login_id", login_id);
            cmd.Parameters.AddWithValue("@first_name", first_name);
            cmd.Parameters.AddWithValue("@middle_name", middle_name);
            cmd.Parameters.AddWithValue("@last_name", last_name);
          
            cmd.Parameters.AddWithValue("@contact_number", contact_number);
            cmd.Parameters.AddWithValue("@email_id", email_id);
            cmd.Parameters.AddWithValue("@address", address);
         
            //Execute the stored proc
            int result = cmd.ExecuteNonQuery();

            return result; //either 1 or 0
              }     
        }


        public DataTable display_updated_data_DL(string user_id)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("display_data_for_candidate", con);
                                               

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@login_id", user_id);

                cmd.ExecuteNonQuery(); 
                SqlDataAdapter da = new SqlDataAdapter(cmd);
               
                //Take a temporary placeholder to store data
                DataTable dt = new DataTable();
               

                da.Fill(dt);

                return dt;

            }
        }


        public int contract_reject_status(string contract_id)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("rejected_contract_status", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0


            }

        }


        public int contract_reject(string contract_id)
        {


            using (SqlConnection con = new SqlConnection(connection))
            {
                //open the connection
                con.Open();

                //Write SQL Command for Insert
                //Call Stored proc for insert
                SqlCommand cmd = new SqlCommand("rejected_contract", con);

                //What is insert_data?
                cmd.CommandType = CommandType.StoredProcedure;

                //Supply data to the parameters of stored proc
                cmd.Parameters.AddWithValue("@contract_id", contract_id);


                //Execute the stored proc
                int result = cmd.ExecuteNonQuery();

                return result; //either 1 or 0


            }

        }



    }
}
