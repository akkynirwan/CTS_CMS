﻿using System;
using DAL_Library;
//To Take DataTable use the below namespace
using System.Data;

namespace Candidate_BL
{
    public class BL
    {
        public int registration(string login_id, string first_name,string middle_name, string last_name, DateTime dob, string gender,
            string contact_number, string email_id, string address, string city_code, string type, string country_code)
        {
            Candidate_DAL d = new Candidate_DAL();
            return d.registration(login_id,first_name,middle_name,last_name,dob,gender,contact_number,email_id,address,city_code,type,country_code);

        }

        public int credentials(string login_id, string password)
        {
            Candidate_DAL d = new Candidate_DAL();
            return d.credentials(login_id,password);

        }



        public bool validate_user(string username, string password)
        {
            Candidate_DAL d = new Candidate_DAL();
            DataTable dt = d.login_data(username, password);

            if (dt.Rows.Count > 0)  //if username and password is found
            {
                return true;
            }
            else
            {
                return false;
            }

        }


        public string user_type(string username)
        {
            Candidate_DAL d = new Candidate_DAL();
            DataTable dt = d.user_type_dal(username);
            string a = String.Empty;
            if (dt.Rows.Count > 0)  //if username and password is found
            {
                
              a=dt.Rows[0]["type"].ToString();

              return a; 
            }
            else
            {
                return a;
            }

        }

        public int create_contract(string contractor_login_id, string contract_name,
           string contract_category, DateTime start_date, DateTime end_date, string status,
           string terms)
        {
            Candidate_DAL d = new Candidate_DAL();
            return d.create_contract(contractor_login_id,contract_name, contract_category,start_date,end_date,status, terms);

        }

        public int insert_amenities(string contract_id, string supplier_id,
          string contract_satus,string category_id,string feedback ,DateTime status_recent_update_dates,string amenities_features)
        {
            Candidate_DAL d = new Candidate_DAL();
            return d.insert_amenities(contract_id, supplier_id,
          contract_satus, category_id, feedback, status_recent_update_dates, amenities_features);
        }


        public int update_contract(string contract_id) {

            Candidate_DAL d = new Candidate_DAL();
            return d.contract_update_status(contract_id);
        }

        public int approved_contract(string contract_id)
        {

            Candidate_DAL d = new Candidate_DAL();
            return d.contract_approved_status(contract_id);
        }


      


        public int approved_contract_amenities(string contract_id)
        {

            Candidate_DAL d = new Candidate_DAL();
            return d.contract_approved_status_amenities(contract_id);
        }
       

        public int edit_user_details(string login_id,string first_name, string middle_name,
            string last_name, string contact_number, string email_id,
            string address)
        {

            Candidate_DAL d = new Candidate_DAL();
            return d.edit_user_details(login_id,first_name, middle_name, last_name, contact_number, email_id,address);
        }
        public DataTable display_updated_data_BL(string user_id)
        {
            Candidate_DAL d = new Candidate_DAL();
            return d.display_updated_data_DL(user_id);
        }

        public int reject_contract(string contract_id)
        {

            Candidate_DAL d = new Candidate_DAL();
            return d.contract_reject_status(contract_id);

        }
        public int reject(string contract_id)
        {

            Candidate_DAL d = new Candidate_DAL();
            return d.contract_reject(contract_id);


        }

    }
}
