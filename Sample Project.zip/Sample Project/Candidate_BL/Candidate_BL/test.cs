﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Candidate_BL
{
    class test
    {
        public static void Main(string[] args)
        {
            BL b = new BL();
            Console.WriteLine(b.user_type("1"));
            
        }
    }
}
